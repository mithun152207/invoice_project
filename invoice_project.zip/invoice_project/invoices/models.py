# invoices/models.py
from django.db import models

class Invoice(models.Model):
    customer_name = models.CharField(max_length=100)
    date = models.DateField(auto_now_add=True)
    tax_rate = models.DecimalField(max_digits=5, decimal_places=2)  # e.g. 10.00 for 10%

    def __str__(self):
        return f"Invoice #{self.id} - {self.customer_name}"

    def subtotal(self):
        return sum(item.total_price() for item in self.lineitem_set.all())

    def tax_amount(self):
        return self.subtotal() * (self.tax_rate / 100)

    def total(self):
        return self.subtotal() + self.tax_amount()


class LineItem(models.Model):
    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE)
    description = models.CharField(max_length=200)
    quantity = models.IntegerField()
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)

    def total_price(self):
        return self.quantity * self.unit_price


