# invoices/views.py
from django.shortcuts import render, redirect
from .forms import InvoiceForm, LineItemFormSet

def create_invoice(request):
    if request.method == 'POST':
        form = InvoiceForm(request.POST)
        formset = LineItemFormSet(request.POST)

        if form.is_valid() and formset.is_valid():
            invoice = form.save()
            line_items = formset.save(commit=False)

            for item in line_items:
                item.invoice = invoice
                item.save()

            return redirect('invoice_detail', invoice_id=invoice.id)
    else:
        form = InvoiceForm()
        formset = LineItemFormSet()

    return render(request, 'invoices/invoice_form.html', {
        'form': form,
        'formset': formset,
    })


from django.shortcuts import get_object_or_404

def invoice_detail(request, invoice_id):
    invoice = get_object_or_404(invoice, pk=invoice_id)
    line_items = invoice.lineitem_set.all()
    return render(request, 'invoices/invoice_detail.html', {
        'invoice': invoice,
        'line_items': line_items,
        'subtotal': invoice.subtotal(),
        'tax': invoice.tax_amount(),
        'total': invoice.total(),
    })


