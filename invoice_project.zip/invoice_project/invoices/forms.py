# invoices/forms.py
from django import forms
from .models import Invoice, LineItem
from django.forms import inlineformset_factory

class InvoiceForm(forms.ModelForm):
    class Meta:
        model = Invoice
        fields = ['customer_name', 'tax_rate']

class LineItemForm(forms.ModelForm):
    class Meta:
        model = LineItem
        fields = ['description', 'quantity', 'unit_price']

LineItemFormSet = inlineformset_factory(
    Invoice, LineItem,
    form=LineItemForm,
    extra=1,
    can_delete=True
)

